package com.example.nagakrishna.farmville_new;

/**
 * Created by Naga Krishna on 25-02-2016.
 */
public interface WeatherServiceListener {
    void servicesuccess(String str);
}
